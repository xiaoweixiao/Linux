#include <stdio.h>

void print_test()
{
    printf("this is a lib!!\n");
}
